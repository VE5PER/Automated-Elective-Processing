package com.example.automated_elective_processing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
