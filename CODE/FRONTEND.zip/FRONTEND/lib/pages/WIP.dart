import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WIP extends StatelessWidget {
  const WIP({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Icon(Icons.construction, size: 500,),);
  }
}
