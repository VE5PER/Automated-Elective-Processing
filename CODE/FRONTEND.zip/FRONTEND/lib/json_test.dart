void main() {
  String js = '''{
    "name": "John Smith",
  "email": "john@example.com"
}
 ''';
//print(js.toJson())

}
